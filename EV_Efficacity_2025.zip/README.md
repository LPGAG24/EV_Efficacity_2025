# EV_Efficacity_2025

# Modélisation charge VE

Ce dépôt contient le pipeline de données, les modèles et l’interface
graphique pour simuler la charge des véhicules électriques au Canada.
